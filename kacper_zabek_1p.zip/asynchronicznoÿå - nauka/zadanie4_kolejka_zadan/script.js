// TODO: uzupelnij zadanie wedlug instrukcji
let table = ["zadanie1", "zadanie2","zadanie3","zadanie4"];
let i = 0;
const wypisz = setInterval(function(){
    document.write(table[i] + "<br>");
    i++;
    if(i >= 4){
        clearInterval(wypisz);
        document.write("Koniec")
    }
},1000)
