// TODO: uzupelnij zadanie wedlug instrukcji
document.write("Rozpoczynam operację");

const sukces = setTimeout(function(){
    document.write("sukces");
 clearTimeout(porazka);
},2000)

const porazka = setTimeout(function(){
    document.write("Porazka")
},5000)