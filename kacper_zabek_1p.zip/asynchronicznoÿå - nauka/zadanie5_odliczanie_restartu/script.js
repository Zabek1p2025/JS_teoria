// TODO: uzupelnij zadanie wedlug instrukcji
let i = 10;

const timer = setInterval(function(){
    document.write(i + "<br>");
    i--;
if(i == 0){
    document.write("Koniec");
    clearInterval(timer);
}
},1000)