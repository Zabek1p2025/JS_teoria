// TODO: uzupelnij zadanie wedlug instrukcji
let i = 1; 
const timer = setInterval(function(){
    document.write("numer pruby" +" "+ i + "<br>");
    i++;
    if(i >3){
        clearInterval(timer);
        document.write("dalsze pruby przerwane");
    }
},2000)