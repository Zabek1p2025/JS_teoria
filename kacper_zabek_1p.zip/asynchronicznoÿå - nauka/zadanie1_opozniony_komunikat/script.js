// TODO: uzupelnij zadanie wedlug instrukcji
document.write("Start Aplikacji")
setTimeout(function(){
    document.write("Moduł gotowy")
}, 2000);