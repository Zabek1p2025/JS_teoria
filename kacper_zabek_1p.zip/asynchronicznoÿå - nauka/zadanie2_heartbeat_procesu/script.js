// TODO: uzupelnij zadanie wedlug instrukcji
let licznik = 0;
const heartbeat = setInterval(function(){
     licznik++;
     document.write("heartbeat"+" "+ licznik);
     if (licznik >= 5 ){
         clearInterval(heartbeat);
     }
},1000)
